//
//  MemeCollectionViewCell.swift
//  Meme1.0_reloaded
//
//  Created by Gaston Gasquet on 3/21/17.
//  Copyright © 2017 Gaston Gasquet. All rights reserved.
//

import UIKit

class MemeCollectionViewCell: UICollectionViewCell {
   
    @IBOutlet weak var memeLabel: UILabel!
    @IBOutlet weak var memeImage: UIImageView!
    
    
    
    
}




//<UICollectionViewCell 0x7fe33cd14230> setValue:forUndefinedKey:]: this class is not key value coding-compliant for the key memeImage.'
