//
//  MemeObject.swift
//  Meme1.0_reloaded
//
//  Created by Gaston Gasquet on 2/28/17.
//  Copyright © 2017 Gaston Gasquet. All rights reserved.
//

import UIKit
import Foundation

struct MemeObject {
    var topText: String?
    var bottomText: String?
    var originalImage: UIImage?
    var memedImage: UIImage!
}
