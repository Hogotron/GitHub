//
//  LoginViewController.swift
//  P_On_The Map
//
//  Created by Gaston Gasquet on 4/20/17.
//  Copyright © 2017 Gaston Gasquet. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController {

    
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    @IBAction func loginButton(_ sender: UIButton) {
        UdacityNetworking.sharedInstance().loginToUdacity(username: Constants.ParameterKeys.username, password: Constants.ParameterKeys.password, completionHandlerForLogin: {(success, result, error) in
            if success {
                self.completeLogin()
                } else {
                    self.displayError()
            }

        }
        
    )}
    

    func alertAction() {
        let alertController = UIAlertController(title: "Error", message: "Bad name or password", preferredStyle: .alert)
        let defaultAction = UIAlertAction(title: "OK", style: .default, handler: nil)
        alertController.addAction(defaultAction)
        
        self.present(alertController, animated: true, completion: nil)
    }
        
        func completeLogin() {
            print("Yeah")
        }
    
        func displayError() {
            print("Error")
        }

    }




