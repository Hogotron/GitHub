//
//  UdacityNetworking.swift
//  P_On_The Map
//
//  Created by Gaston Gasquet on 4/21/17.
//  Copyright © 2017 Gaston Gasquet. All rights reserved.
//

import Foundation
import UIKit


class UdacityNetworking: NSObject {
    
    var session = URLSession.shared
    var appDelegate: AppDelegate!

    override init() {
        super.init()
    }

    
    
    
    
    
    
    
    
    
    
    class func sharedInstance() -> UdacityNetworking {
        struct Singleton {
            static var sharedInstance = UdacityNetworking()
        }
        return Singleton.sharedInstance
    }

    
}
