//
//  Contstants.swift
//  P_On_The Map
//
//  Created by Gaston Gasquet on 4/20/17.
//  Copyright © 2017 Gaston Gasquet. All rights reserved.
//

import Foundation


struct Constants  {
    
    struct urlUdacity {
        static let baseURL = "https://www.udacity.com/api"
        static let sessionURL = "https://www.udacity.com/api/session"
        static let userURL = "https://www.udacity.com/api/users"
    }

    struct ParameterKeys {
        static let udacity = "udacity"
        static let username = "username"
        static let password = "password"
        static let sessionID = "session"
    }
    
    struct JSONResponseKeys {
        
        static let userID = "userID"
        
        static let firstName = "first_name"
        static let lastName = "last_name"
        
        
        static let account = "account"
        static let session = "session"
        static let accountKey = "key"
        static let expiration = "expiration"
    }
    
}

