//
//  MemeObject.swift
//  Meme2.0_reloaded
//
//  Created by Gaston Gasquet on 2/28/17.
//  Copyright © 2017 Gaston Gasquet. All rights reserved.
//

import UIKit
import Foundation

struct MemeObject {
    let topText: String?
    let bottomText: String?
    let originalImage: UIImage?
    var memedImage: UIImage!

}
