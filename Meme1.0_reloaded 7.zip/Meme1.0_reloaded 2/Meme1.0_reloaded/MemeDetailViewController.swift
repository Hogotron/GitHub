//
//  MemeDetailViewController.swift
//  Meme2.0_reloaded
//
//  Created by Gaston Gasquet on 3/19/17.
//  Copyright © 2017 Gaston Gasquet. All rights reserved.
//

import UIKit

class MemeDetailViewController: UIViewController, UIApplicationDelegate {
    
    @IBOutlet weak var imageV: UIImageView!
   
    
    var meme: MemeObject!
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        reloadInputViews()
        imageV.image = meme.memedImage
        imageV.contentMode = .scaleAspectFit
        tabBarController?.tabBar.isHidden = true
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        tabBarController?.tabBar.isHidden = false
    }
    
}


