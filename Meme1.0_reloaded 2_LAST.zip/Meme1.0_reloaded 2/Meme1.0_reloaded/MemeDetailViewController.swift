//
//  MemeDetailViewController.swift
//  Meme1.0_reloaded
//
//  Created by Gaston Gasquet on 3/19/17.
//  Copyright © 2017 Gaston Gasquet. All rights reserved.
//

import UIKit

class MemeDetailViewController: UIViewController, UIApplicationDelegate {
    
    @IBOutlet weak var imageV: UIImageView!
    
    var meme: MemeObject!
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.reloadInputViews()
        self.imageV.image = meme.memedImage
        self.tabBarController?.tabBar.isHidden = true
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.tabBarController?.tabBar.isHidden = false
    }


}


