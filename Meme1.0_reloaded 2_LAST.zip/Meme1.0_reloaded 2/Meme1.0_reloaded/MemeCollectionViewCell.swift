//
//  MemeCollectionViewCell.swift
//  Meme1.0_reloaded
//
//  Created by Gaston Gasquet on 3/21/17.
//  Copyright © 2017 Gaston Gasquet. All rights reserved.
//

import UIKit

class MemeCollectionViewCell: UICollectionViewCell {
   
   // @IBOutlet weak var memeLabel: UILabel!
    @IBOutlet weak var memeImage: UIImageView!
    
    
    
    
}





