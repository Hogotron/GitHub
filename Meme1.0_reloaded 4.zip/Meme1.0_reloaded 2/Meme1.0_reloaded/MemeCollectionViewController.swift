//
//  MemeCollectionViewController.swift
//  Meme1.0_reloaded
//
//  Created by Gaston Gasquet on 3/20/17.
//  Copyright © 2017 Gaston Gasquet. All rights reserved.
//

import UIKit
import Foundation

class MemeCollectionViewController: UICollectionViewController {
    
    var memes: [MemeObject] {
        return (UIApplication.shared.delegate as! AppDelegate).memes
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let space: CGFloat = 3.0
        let dimension = (self.view.frame.size.width - (2 * space )) / 3
        //let dimHeight = (self.view.frame.size.height - (2 * space)) / 6
        //flowLayOut.minimumInteritemSpacing = space
        //flowLayOut.minimumLineSpacing = space
        //flowLayOut.itemSize = CGSize(width: dimension, height: dimension)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        self.tabBarController?.tabBar.isHidden = false
        collectionView!.reloadData()
    }
    
    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.memes.count
    }
    
    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "MemeCollectionViewCell", for: indexPath) as! MemeCollectionViewCell
        let meme = self.memes[(indexPath as NSIndexPath).item]
        
        // Set the name and image
        //cell.backgroundColor = UIColor.black
        //cell.memeLabel.text = meme.memeName
        cell.memeImage.image = meme.memedImage
        
        return cell
    }
    
    override func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let detailController = self.storyboard!.instantiateViewController(withIdentifier: "MemeDetailViewController") as! MemeDetailViewController
        detailController.meme = self.memes[(indexPath as NSIndexPath).row]
        
        navigationController!.pushViewController(detailController, animated: true)
        
    }
    
    
    
}

    
    
    
    
    

