//
//  MemeTableViewController.swift
//  Meme1.0_reloaded
//
//  Created by Gaston Gasquet on 3/17/17.
//  Copyright © 2017 Gaston Gasquet. All rights reserved.
//

import UIKit

class MemeTableViewController: UITableViewController {
    
    var memes: [MemeObject] {
        return (UIApplication.shared.delegate as! AppDelegate).memes
        
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        tableView.reloadData()
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.memes.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CellView")!
        let meme = memes[indexPath.row]
        
        let topMemeText = meme.topText
        let bottomMemeText = meme.bottomText
        let cellText = topMemeText! + " " + bottomMemeText!
        cell.textLabel?.text = cellText
        
        cell.imageView?.image = meme.memedImage
        
        return cell
    }

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let detailController = self.storyboard?.instantiateViewController(withIdentifier: "MemeDetailViewController") as! MemeDetailViewController
        detailController.meme = memes[indexPath.row]
        
        navigationController!.pushViewController(detailController, animated: true)

    }
}
