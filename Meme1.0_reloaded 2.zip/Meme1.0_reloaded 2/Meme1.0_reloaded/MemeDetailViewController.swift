//
//  MemeDetailViewController.swift
//  Meme1.0_reloaded
//
//  Created by Gaston Gasquet on 3/19/17.
//  Copyright © 2017 Gaston Gasquet. All rights reserved.
//

import UIKit

class MemeDetailViewController: UIViewController {
    
    var meme: MemeObject!

}
